declare module 'crypto-js';


