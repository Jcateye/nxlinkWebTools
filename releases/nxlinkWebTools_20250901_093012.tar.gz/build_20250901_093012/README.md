# nxlinkWebTools 生产部署包

构建时间: 20250901_093012

## 部署步骤

1. **配置环境变量**
   ```bash
   cp production.env.example production.env
   # 编辑 production.env 填入实际配置
   ```

2. **运行部署脚本**
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

3. **启动服务**
   ```bash
   npm run start:prod
   # 或
   ./start.js prod
   ```

## 服务端口

- 网关服务: 8350
- 后端服务: 8450

## 目录结构

- `dist/` - 前端构建产物
- `server-dist/` - 后端构建产物
- `server-config/` - 后端配置文件
- `server-public/` - 后端静态资源
- `config/` - 项目配置
- `server.js` - 生产服务器入口
- `start.js` - 启动脚本

## 注意事项

1. 确保服务器已安装 Node.js 16+
2. 确保配置文件中的敏感信息安全
3. 建议使用 PM2 或 systemd 管理进程
