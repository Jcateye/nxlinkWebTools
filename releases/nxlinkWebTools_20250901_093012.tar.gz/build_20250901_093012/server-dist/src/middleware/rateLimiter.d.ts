import { Request, Response, NextFunction } from 'express';
export declare const rateLimiter: (req: Request, res: Response, next: NextFunction) => void;
//# sourceMappingURL=rateLimiter.d.ts.map