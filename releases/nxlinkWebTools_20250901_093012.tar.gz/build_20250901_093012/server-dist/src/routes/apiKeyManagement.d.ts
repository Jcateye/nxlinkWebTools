declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=apiKeyManagement.d.ts.map