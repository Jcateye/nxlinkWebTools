"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const axios_1 = __importDefault(require("axios"));
const crypto_js_1 = __importDefault(require("crypto-js"));
const configManager_1 = require("../services/configManager");
const router = express_1.default.Router();
function generateContactIdFromPhone(phone) {
    const base28 = crypto_js_1.default.MD5(String(phone || '')).toString().toLowerCase().substring(0, 28);
    const saltSource = `${Date.now()}-${Math.random()}`;
    const salt8 = crypto_js_1.default.MD5(saltSource).toString().toLowerCase().substring(0, 8);
    const mixed = base28 + salt8;
    return `${mixed.substring(0, 8)}-${mixed.substring(8, 12)}-${mixed.substring(12, 16)}-${mixed.substring(16, 20)}-${mixed.substring(20, 32)}`;
}
function buildOpenApiHeaders(authConfig, body) {
    const { accessKey, accessSecret, bizType, action, ts } = authConfig;
    const headersStr = `accessKey=${accessKey}&action=${action}&bizType=${bizType}&ts=${ts}`;
    let raw = headersStr;
    const bodyJsonString = JSON.stringify(body);
    if (bodyJsonString && bodyJsonString !== '{}') {
        raw += `&body=${bodyJsonString}`;
    }
    raw += `&accessSecret=${accessSecret}`;
    const sign = crypto_js_1.default.MD5(raw).toString();
    console.log(`[OpenAPI Debug] String to sign: "${raw}"`);
    return {
        'Content-Type': 'application/json',
        'accessKey': accessKey,
        'bizType': bizType,
        'action': action,
        'ts': ts,
        'sign': sign,
        'algorithm': 'md5'
    };
}
function validateApiKey(apiKey) {
    const allKeys = (0, configManager_1.getAllApiKeys)();
    const apiKeyConfig = allKeys.find(key => key.apiKey === apiKey);
    if (!apiKeyConfig) {
        return { valid: false, error: 'Invalid API Key' };
    }
    if (!apiKeyConfig.openapi.accessKey || !apiKeyConfig.openapi.accessSecret) {
        return { valid: false, error: 'API Key configuration incomplete' };
    }
    return { valid: true, config: apiKeyConfig };
}
router.post('/public/:apiKey/:taskId/append-numbers', async (req, res) => {
    try {
        const { apiKey, taskId } = req.params;
        const { countryCode } = req.query;
        const { phones } = req.body;
        console.log(`[${new Date().toLocaleString()}] 📞 公开API追加号码请求:`, {
            apiKey: apiKey.substring(0, 8) + '***',
            taskId,
            countryCode,
            phoneCount: phones?.length || 0
        });
        const validation = validateApiKey(apiKey);
        if (!validation.valid) {
            res.status(401).json({
                code: 401,
                message: validation.error,
                error: 'UNAUTHORIZED'
            });
            return;
        }
        if (!taskId) {
            res.status(400).json({
                code: 400,
                message: 'Missing required parameter: taskId',
                error: 'MISSING_PARAMETERS'
            });
            return;
        }
        const finalCountryCode = countryCode || '86';
        if (!phones || !Array.isArray(phones) || phones.length === 0) {
            res.status(400).json({
                code: 400,
                message: 'Invalid phones data',
                error: 'INVALID_PHONES_DATA'
            });
            return;
        }
        const apiKeyConfig = validation.config;
        const openApiConfig = {
            baseURL: apiKeyConfig.openapi.baseUrl,
            auth: {
                accessKey: apiKeyConfig.openapi.accessKey,
                accessSecret: apiKeyConfig.openapi.accessSecret,
                bizType: apiKeyConfig.openapi.bizType
            }
        };
        const requestBody = {
            taskId,
            countryCode: String(finalCountryCode),
            appendNumbers: phones.map(item => ({
                phoneNumber: item.phone,
                params: item.params || []
            }))
        };
        const headers = buildOpenApiHeaders({
            accessKey: openApiConfig.auth.accessKey,
            accessSecret: openApiConfig.auth.accessSecret,
            bizType: openApiConfig.auth.bizType,
            action: 'callAppend',
            ts: String(Date.now())
        }, requestBody);
        console.log(`[${new Date().toLocaleString()}] 🚀 调用OpenAPI追加号码:`, {
            baseURL: openApiConfig.baseURL,
            taskId,
            countryCode: finalCountryCode,
            phoneCount: phones.length
        });
        const response = await axios_1.default.post(`${openApiConfig.baseURL}/openapi/aiagent/call/append`, requestBody, { headers });
        console.log(`[${new Date().toLocaleString()}] ✅ OpenAPI响应:`, {
            code: response.data?.code,
            message: response.data?.msg || response.data?.message
        });
        res.json({
            code: 200,
            message: '号码追加成功',
            data: response.data?.data || response.data,
            request: {
                taskId,
                countryCode,
                phoneCount: phones.length
            }
        });
        return;
    }
    catch (error) {
        console.error(`[${new Date().toLocaleString()}] ❌ 公开API追加号码失败:`, error.message);
        if (error.response) {
            res.status(error.response.status || 500).json({
                code: error.response.status || 500,
                message: error.response.data?.message || error.message,
                error: 'OPENAPI_ERROR',
                details: error.response.data
            });
        }
        else {
            res.status(500).json({
                code: 500,
                message: error.message || 'Internal server error',
                error: 'INTERNAL_ERROR'
            });
        }
        return;
    }
});
router.post('/public/:apiKey/:taskId/:countryCode/append-numbers', async (req, res) => {
    try {
        const { apiKey, taskId, countryCode } = req.params;
        const { phones } = req.body;
        console.log(`[${new Date().toLocaleString()}] 📞 公开API追加号码请求:`, {
            apiKey: apiKey.substring(0, 8) + '***',
            taskId,
            countryCode,
            phoneCount: phones?.length || 0
        });
        const validation = validateApiKey(apiKey);
        if (!validation.valid) {
            res.status(401).json({
                code: 401,
                message: validation.error,
                error: 'UNAUTHORIZED'
            });
            return;
        }
        if (!taskId || !countryCode) {
            res.status(400).json({
                code: 400,
                message: 'Missing required parameters: taskId and countryCode',
                error: 'MISSING_PARAMETERS'
            });
            return;
        }
        if (!phones || !Array.isArray(phones) || phones.length === 0) {
            res.status(400).json({
                code: 400,
                message: 'Invalid phones data',
                error: 'INVALID_PHONES_DATA'
            });
            return;
        }
        const apiKeyConfig = validation.config;
        const openApiConfig = {
            baseURL: apiKeyConfig.openapi.baseUrl,
            auth: {
                accessKey: apiKeyConfig.openapi.accessKey,
                accessSecret: apiKeyConfig.openapi.accessSecret,
                bizType: apiKeyConfig.openapi.bizType
            }
        };
        const requestBody = {
            taskId,
            countryCode,
            appendNumbers: phones.map(item => ({
                phoneNumber: item.phone,
                params: item.params || []
            }))
        };
        const headers = buildOpenApiHeaders({
            accessKey: openApiConfig.auth.accessKey,
            accessSecret: openApiConfig.auth.accessSecret,
            bizType: openApiConfig.auth.bizType,
            action: 'callAppend',
            ts: String(Date.now())
        }, requestBody);
        console.log(`[${new Date().toLocaleString()}] 🚀 调用OpenAPI追加号码:`, {
            baseURL: openApiConfig.baseURL,
            taskId,
            countryCode,
            phoneCount: phones.length
        });
        const response = await axios_1.default.post(`${openApiConfig.baseURL}/openapi/aiagent/call/append`, requestBody, { headers });
        console.log(`[${new Date().toLocaleString()}] ✅ OpenAPI响应:`, {
            code: response.data?.code,
            message: response.data?.msg || response.data?.message
        });
        res.json({
            code: 200,
            message: '号码追加成功',
            data: response.data?.data || response.data,
            request: {
                taskId,
                countryCode,
                phoneCount: phones.length
            }
        });
        return;
    }
    catch (error) {
        console.error(`[${new Date().toLocaleString()}] ❌ 公开API追加号码失败:`, error.message);
        if (error.response) {
            res.status(error.response.status || 500).json({
                code: error.response.status || 500,
                message: error.response.data?.message || error.message,
                error: 'OPENAPI_ERROR',
                details: error.response.data
            });
        }
        else {
            res.status(500).json({
                code: 500,
                message: error.message || 'Internal server error',
                error: 'INTERNAL_ERROR'
            });
        }
        return;
    }
});
router.get('/public/:apiKey/:taskId/call-records', async (req, res) => {
    try {
        const { apiKey, taskId } = req.params;
        const { pageNumber = 1, pageSize = 10, status } = req.query;
        console.log(`[${new Date().toLocaleString()}] 📋 公开API获取通话记录:`, {
            apiKey: apiKey.substring(0, 8) + '***',
            taskId,
            pageNumber,
            pageSize,
            status
        });
        const validation = validateApiKey(apiKey);
        if (!validation.valid) {
            res.status(401).json({
                code: 401,
                message: validation.error,
                error: 'UNAUTHORIZED'
            });
            return;
        }
        if (!taskId) {
            res.status(400).json({
                code: 400,
                message: 'Missing required parameter: taskId',
                error: 'MISSING_PARAMETERS'
            });
            return;
        }
        const apiKeyConfig = validation.config;
        const openApiConfig = {
            baseURL: apiKeyConfig.openapi.baseUrl,
            auth: {
                accessKey: apiKeyConfig.openapi.accessKey,
                accessSecret: apiKeyConfig.openapi.accessSecret,
                bizType: apiKeyConfig.openapi.bizType
            }
        };
        const requestBody = {
            taskId,
            pageNumber: Number(pageNumber),
            pageSize: Number(pageSize),
            ...(status && { status })
        };
        const headers = buildOpenApiHeaders({
            accessKey: openApiConfig.auth.accessKey,
            accessSecret: openApiConfig.auth.accessSecret,
            bizType: openApiConfig.auth.bizType,
            action: 'pageCallRecords',
            ts: String(Date.now())
        }, requestBody);
        const response = await axios_1.default.post(`${openApiConfig.baseURL}/openapi/aiagent/call/list`, requestBody, { headers });
        res.json({
            code: 200,
            message: '获取成功',
            data: response.data?.data || response.data
        });
        return;
    }
    catch (error) {
        console.error(`[${new Date().toLocaleString()}] ❌ 公开API获取通话记录失败:`, error.message);
        if (error.response) {
            res.status(error.response.status || 500).json({
                code: error.response.status || 500,
                message: error.response.data?.message || error.message,
                error: 'OPENAPI_ERROR',
                details: error.response.data
            });
        }
        else {
            res.status(500).json({
                code: 500,
                message: error.message || 'Internal server error',
                error: 'INTERNAL_ERROR'
            });
        }
        return;
    }
});
router.delete('/public/:apiKey/:taskId/:contactId/delete', async (req, res) => {
    try {
        const { apiKey, taskId, contactId } = req.params;
        console.log(`[${new Date().toLocaleString()}] 🗑️ 公开API删除号码:`, {
            apiKey: apiKey.substring(0, 8) + '***',
            taskId,
            contactId
        });
        const validation = validateApiKey(apiKey);
        if (!validation.valid) {
            res.status(401).json({
                code: 401,
                message: validation.error,
                error: 'UNAUTHORIZED'
            });
            return;
        }
        if (!taskId || !contactId) {
            res.status(400).json({
                code: 400,
                message: 'Missing required parameters: taskId and contactId',
                error: 'MISSING_PARAMETERS'
            });
            return;
        }
        const apiKeyConfig = validation.config;
        const openApiConfig = {
            baseURL: apiKeyConfig.openapi.baseUrl,
            auth: {
                accessKey: apiKeyConfig.openapi.accessKey,
                accessSecret: apiKeyConfig.openapi.accessSecret,
                bizType: apiKeyConfig.openapi.bizType
            }
        };
        const requestBody = {
            taskId,
            contactIds: [contactId]
        };
        const headers = buildOpenApiHeaders({
            accessKey: openApiConfig.auth.accessKey,
            accessSecret: openApiConfig.auth.accessSecret,
            bizType: openApiConfig.auth.bizType,
            action: 'deleteCallRecords',
            ts: String(Date.now())
        }, requestBody);
        const response = await axios_1.default.post(`${openApiConfig.baseURL}/openapi/aiagent/call/delete`, requestBody, { headers });
        res.json({
            code: 200,
            message: '删除成功',
            data: response.data?.data || response.data
        });
        return;
    }
    catch (error) {
        console.error(`[${new Date().toLocaleString()}] ❌ 公开API删除号码失败:`, error.message);
        if (error.response) {
            res.status(error.response.status || 500).json({
                code: error.response.status || 500,
                message: error.response.data?.message || error.message,
                error: 'OPENAPI_ERROR',
                details: error.response.data
            });
        }
        else {
            res.status(500).json({
                code: 500,
                message: error.message || 'Internal server error',
                error: 'INTERNAL_ERROR'
            });
        }
        return;
    }
});
router.post('/public/:apiKey/:taskId/form-submission', async (req, res) => {
    try {
        const { apiKey, taskId } = req.params;
        const { countryCode } = req.query;
        const webhookData = req.body;
        console.log(`[${new Date().toLocaleString()}] 📝 公开表单提交接口（重构版）:`, {
            apiKey: apiKey.substring(0, 8) + '***',
            taskId,
            countryCode,
            formId: webhookData.form,
            phoneNumber: webhookData.entry?.field_5
        });
        const validation = validateApiKey(apiKey);
        if (!validation.valid) {
            res.status(401).json({
                code: 401,
                message: validation.error,
                error: 'UNAUTHORIZED'
            });
            return;
        }
        if (!taskId) {
            res.status(400).json({
                code: 400,
                message: 'Missing required parameter: taskId',
                error: 'MISSING_PARAMETERS'
            });
            return;
        }
        if (!webhookData.entry || !webhookData.entry.field_5) {
            res.status(400).json({
                code: 400,
                message: 'Missing required field: field_5 (phone number)',
                error: 'MISSING_PHONE_NUMBER'
            });
            return;
        }
        const finalCountryCode = countryCode || '86';
        const apiKeyConfig = validation.config;
        const openApiConfig = {
            baseURL: apiKeyConfig.openapi.baseUrl,
            auth: {
                accessKey: apiKeyConfig.openapi.accessKey,
                accessSecret: apiKeyConfig.openapi.accessSecret,
                bizType: apiKeyConfig.openapi.bizType
            }
        };
        const phoneNumber = String(webhookData.entry.field_5);
        const requestBody = {
            taskId,
            list: [{
                    contactId: generateContactIdFromPhone(phoneNumber),
                    phoneNumber: phoneNumber,
                    name: phoneNumber,
                    params: []
                }]
        };
        if (countryCode) {
            requestBody.countryCode = String(finalCountryCode);
        }
        console.log(`[${new Date().toLocaleString()}] 📦 最终请求体:`, JSON.stringify(requestBody));
        const headers = buildOpenApiHeaders({
            accessKey: openApiConfig.auth.accessKey,
            accessSecret: openApiConfig.auth.accessSecret,
            bizType: openApiConfig.auth.bizType,
            action: 'callAppend',
            ts: String(Date.now())
        }, requestBody);
        const response = await axios_1.default.post(`${openApiConfig.baseURL}/openapi/aiagent/call/append`, requestBody, { headers });
        console.log(`[${new Date().toLocaleString()}] ✅ OpenAPI响应:`, {
            code: response.data?.code,
            message: response.data?.msg || response.data?.message
        });
        res.json({
            code: 200,
            message: '表单数据处理成功',
            data: response.data?.data || response.data,
            request: {
                taskId,
                countryCode: finalCountryCode,
                phoneNumber: String(webhookData.entry.field_5),
                formId: webhookData.form
            }
        });
        return;
    }
    catch (error) {
        console.error(`[${new Date().toLocaleString()}] ❌ 公开表单提交失败:`, error.message);
        if (error.response) {
            res.status(error.response.status || 500).json({
                code: error.response.status || 500,
                message: error.response.data?.message || error.message,
                error: 'OPENAPI_ERROR',
                details: error.response.data
            });
        }
        else {
            res.status(500).json({
                code: 500,
                message: error.message || 'Internal server error',
                error: 'INTERNAL_ERROR'
            });
        }
        return;
    }
});
exports.default = router;
//# sourceMappingURL=publicApi.js.map