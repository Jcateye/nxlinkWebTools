import { Server as SocketIOServer } from 'socket.io';
export declare function setupSocketHandlers(io: SocketIOServer): void;
//# sourceMappingURL=testSocket.d.ts.map