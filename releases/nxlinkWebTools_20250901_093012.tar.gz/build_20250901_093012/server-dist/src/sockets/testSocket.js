"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupSocketHandlers = setupSocketHandlers;
function setupSocketHandlers(io) {
    console.log('Socket处理器已设置（空实现）');
}
//# sourceMappingURL=testSocket.js.map