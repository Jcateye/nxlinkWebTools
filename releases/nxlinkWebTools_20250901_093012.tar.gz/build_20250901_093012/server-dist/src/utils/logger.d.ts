import winston from 'winston';
export declare const logger: winston.Logger;
//# sourceMappingURL=logger.d.ts.map