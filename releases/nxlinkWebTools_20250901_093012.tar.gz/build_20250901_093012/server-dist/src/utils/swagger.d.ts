import { Express } from 'express';
export declare function setupSwagger(app: Express): void;
//# sourceMappingURL=swagger.d.ts.map