"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupSwagger = setupSwagger;
function setupSwagger(app) {
    console.log('Swagger配置已加载（空实现）');
}
//# sourceMappingURL=swagger.js.map